#include<stdio.h>
#include<windows.h>
#include <conio.h>
#include "union_fucntion.h"
#include "manager.h"
#include "position.h"


typedef struct {
   char ID[30];
   char PW[20];
   char car_num[30];
   char name[20];
   int point;
}MemList;
int manager_mode()// manager_mode(List *)
{
   int menuNum_manager;
   int menuNum_sales;
   int res;
   CLEAR;
   res = input_identify();
   if (res == 0) return 0;//���α׷� ����
   system("cls");

      while (1)
      {
   PT2:
      menuNum_manager = managerList();
      system("cls");
   PT1:
      switch (menuNum_manager)
      {
      case 1:
		 park_info_show_manager();
		 CLEAR;
         break;
      case 2:
         memberManage();
         getch();
         system("cls");

         break;
      case 3:
         menuNum_sales = salesList();
         system("cls");      
         if (menuNum_sales == 1)
         {
            todaySale();
            getch();
            system("cls");
            goto PT1;
         }
         else if (menuNum_sales == 2)
         {
            dailySale();
            myflush();
            getch();
            system("cls");
            goto PT1;
         }
         else if(menuNum_sales == 3)
         {
            montlySale();
            myflush();
            getch();
            system("cls");
            goto PT1;
         }
         else
         {
            goto PT2;
         }
         break;
      default:
         return 0;
      }
   }
   
   return 0;
}
int managerList()
{
   int menuNum;

   printf("\n\n\n                           <    �����ڸ��    >\n\n\n");
   printf("                              1. ���� ��Ȳ\n\n");
   printf("                              2. ȸ�� ����\n\n");
   printf("                              3. ���� ����\n\n");
   printf("                              4. ����\n\n\n\n");
   printf("                            # ���� : ");

   menuNum = filter(1, 4);

   return menuNum;
}
void memberManage()//����Ʈ�����ͼ� ���
{
   MemList mem;
   FILE *fp;
   int i,j=0;
   char ch;

   fp = fopen("member_list.txt", "rt");

   printf("\n\n                           <    ȸ�� ����    >\n\n");
   printf("   < ȸ�� �̸� >   < ���� ��ȣ >        < ID >     < PW > < ����Ʈ >\n\n\n");

   while (j<=10)
   {
      i = 0;
      while (1)
      {
         fscanf(fp, "%c", &mem.ID[i]);
         if (mem.ID[i] == '\n')
         {
            mem.ID[i] = '\0';
            break;
         }
         i++;
      }
      i = 0;

      while (1)
      {
         fscanf(fp, "%c", &mem.PW[i]);
         if (mem.PW[i] == '\n')
         {
            mem.PW[i] = '\0';
            break;
         }
         i++;
      }
      i = 0;

      while (1)
      {
         fscanf(fp, "%c", &mem.car_num[i]);
         if (mem.car_num[i] == '\n')
         {
            mem.car_num[i] = '\0';
            break;
         }
         i++;
      }
      i = 0;

      while (1)
      {
         fscanf(fp, "%c", &mem.name[i]);
         if (mem.name[i] == '\n')
         {
            mem.name[i] = '\0';
            break;
         }
         i++;
      }

      fscanf(fp, "%d", &mem.point);
      fscanf(fp, "%c", &ch);
      printf(" %2d.  %s   /   %s   /  %11s  / **** /   %d\n\n",j+1, mem.name, mem.car_num, mem.ID, mem.point);
      j++;
   }
   fclose(fp);
}
int salesList()
{
   int menuNum;

   printf("\n\n\n                           <    ȸ�� ����    >\n\n\n");
   printf("                           1. ���� ���� ��ȸ\n\n");
   printf("                           2. �Ϻ� ���� ��ȸ\n\n");
   printf("                           3. ���� ���� ��ȸ\n\n");
   printf("                           4. ó�� ȭ��\n\n\n\n");
   printf("                         # ���� : ");
   menuNum = filter(1, 4);

   return menuNum;
}
int filter(int start, int end)
{
   int menuNum;
   while (1) {
      scanf("%d", &menuNum);
      if (getchar() != '\n')
      {
         myflush();
         printf("                       # �ٽ� �Է� ���ֽʽÿ� : ");
      }
      else
      {
         if (menuNum >= start && menuNum <= end) break;
         else printf("                       # �ٽ� �Է� ���ֽʽÿ� : ");
      }
   }
   return menuNum;
}
void todaySale()//���� �ð� �ҷ��;���
{
   FILE *fp;
   char ch;
   int date, input_date;
   int tot = 0, pay;
   int i = 0;

   int year, mon, day;

   struct date stdate;
   getdate(&stdate);

   year = stdate.da_year;
   mon = stdate.da_mon;
   day = stdate.da_day;

   fp = fopen("sales.txt", "rt");
   printf("\n\n\n                           <    ���� ����    >\n\n\n");
   if (fp != NULL)
   {
      input_date = year*10000+mon*100+day; // ���� ��¥ �־�ߵ� �ð��Լ�����
      while (1)
      {
         if (feof(fp) != 0) break;
         fscanf(fp, "%d", &date);
         fscanf(fp, "%d", &pay);
         if (date == input_date)
         {
            printf("                            %2d.  %5d��\n",i+1,pay);
            i++;
            tot += pay;
         }
         date = 0;
         pay = 0;         
      }      
      printf("\n                         ���ð� ���� : %5d��", tot);
   }
   fclose(fp);
}
void dailySale()
{
   FILE *fp;
   char ch;
   int date, input_date;
   int tot = 0, pay;
   int i = 0;
   int year, mon, day;

   fp = fopen("sales.txt", "rt");

   printf("\n\n\n                           <   �Ϻ� ����  ��ȸ  >\n\n\n");
   if (fp != NULL)
   {
      printf("                      �⵵ / �� / �� �Է� : ");
      scanf("%d%d%d", &year, &mon, &day);
      printf("\n");
      input_date = year * 10000 + mon * 100 + day;
      
      while (1)
      {
         if (feof(fp) != 0) break;
         fscanf(fp, "%d", &date);
         fscanf(fp, "%d", &pay);
         if (date == input_date)
         {
            printf("                            %2d.  %5d��\n\n", i + 1, pay);
            i++;
            tot += pay;
         }
         date = 0;
         pay = 0;
      }
      printf("\n                      %d�� %d�� %d�� ���� : %5d��",year,mon,day, tot);
   }
   fclose(fp);
}
void montlySale()
{
   FILE *fp;
   char ch;
   int date, input_date;
   int tot = 0, pay;
   int i = 0;
   int year, mon;
   int j = 0;

   fp = fopen("sales.txt", "rt");
   printf("\n\n\n                          <  ���� ����  ��ȸ  >\n\n\n");
   if (fp != NULL)
   {
      printf("                        �⵵ / �� �Է� : ");
      scanf("%d%d", &year, &mon);
      printf("\n\n");
      input_date = year * 100 + mon;
   
      fp = fopen("sales.txt", "rt");
      while (1)
      {
         if (feof(fp) != 0) break;   
         fscanf(fp, "%d", &date);
         fscanf(fp, "%d", &pay);
         if (date / 100 == input_date)
         {
            if (i >= 0 && i < 8)
            {
               j++;
               printf("  %3d.  %5d��  ", i + 1, pay);
               if (j % 4 == 0)printf("\n\n");
            }
                   tot += pay;
               i++;
         }
         date = 0;
         pay = 0;
      }
      printf("                                  : :\n");
      printf("                                  : :\n");
      printf("                                  : :\n");
      printf("                                  : :\n");
      if (i != 0) {
         printf("\n\n\n                            �ѰǼ� : %d��", i + 1);
         printf("\n\n\n                        �Ǵ� ��� ���� : %5d��", tot / i + 1);
         printf("\n\n\n                      %d�� %d�� ���� : %d��", year, mon, tot);
      }
      else {
         printf("\n\n\n                            �ѰǼ� : 0��");
         printf("\n\n\n                        �Ǵ� ��� ���� : 0��");
         printf("\n\n\n                        %d�� %d�� ���� : %d��", year, mon, tot);
      }
   }
   fclose(fp);
}
int input_identify()
{
	{
		FILE *fp;
		char ch;
		char ID[2][20];
		char PW[2][20];
		char input_id[20];
		char input_pw[20];
		int i = 0, j;
		int errorcnt = 1;
		int res;

		fp = fopen("manager_list.txt", "rt");

		printf("\n\n\n                           <    �����ڸ��    >\n\n\n");
		printf("                           ID �Է� :");
		fgets(input_id, 20, stdin);
		printf("\n");
		printf("                           PW �Է� :");
		i = 0;
		while (1)
		{
			ch = getch();
			printf("*");
			input_pw[i] = ch;
			if (ch == '\r')
			{
				input_pw[i] = '\n';
				input_pw[i + 1] = '\0';
				break;
			}
			i++;
		}
		while (errorcnt < 5)
		{
			i = 0;
			while (i < 2)
			{
				j = 0;
				while (1)
				{
					fscanf(fp, "%c", &ID[i][j]);
					if (ID[i][j] == '\n')
					{
						ID[i][j + 1] = '\0';
						break;
					}
					else j++;
				}
				j = 0;
				while (1)
				{
					fscanf(fp, "%c", &PW[i][j]);
					if (PW[i][j] == '\n')
					{
						PW[i][j + 1] = '\0';
						break;
					}
					else j++;
				}
				i++;
			}
			fclose(fp);
			for (i = 0; i < 2; i++)
			{
				if (strcmp(input_id, ID[i]) == 0)
				{
					if (strcmp(input_pw, PW[i]) == 0)
					{
						res = 1;
						goto FN;
					}
					else
					{
						printf("\n             %dȸ ����(5ȸ�̻� ������ ó��ȭ������ ���ư��ϴ�)\n\n", errorcnt);
						printf("                           ID �Է� :");
						fgets(input_id, 20, stdin);
						printf("\n");
						printf("                           PW �Է� :");
						i = 0;
						while (1)
						{
							ch = getch();
							printf("*");
							input_pw[i] = ch;
							if (ch == '\r')
							{
								input_pw[i] = '\n';
								input_pw[i + 1] = '\0';
								break;
							}
							i++;
						}
						res = 0;
						errorcnt++;
					}
				}
			}
			printf("\n             %dȸ ����(5ȸ�̻� ������ ó��ȭ������ ���ư��ϴ�)\n\n", errorcnt);
			printf("                           ID �Է� :");
			fgets(input_id, 20, stdin);
			printf("\n");
			printf("                           PW �Է� :");
			i = 0;
			while (1)
			{
				ch = getch();
				printf("*");
				input_pw[i] = ch;
				if (ch == '\r')
				{
					input_pw[i] = '\n';
					input_pw[i + 1] = '\0';
					break;
				}
				i++;
			}
			res = 0;
			errorcnt++;
		}
	FN:
		return res;

	}

}