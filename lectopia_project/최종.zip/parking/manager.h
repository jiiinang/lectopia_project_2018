#pragma once

extern int sum[3];
extern int empty[3];
extern int park_info[3][4][8];
extern char temp[2];

int managerList();
void memberManage();
int salesList();
int filter(int start, int end);
void todaySale();
void dailySale();
void montlySale();
int input_identify();
void parkselect_manager();