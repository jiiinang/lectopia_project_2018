#include "position.h"
#include "union_fucntion.h"
#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <windows.h>
#include <stdlib.h>


void printinfo(char*car_number, int floor_select, char *temp) 
{
	CLEAR;
	char ch = '\n';
	FILE *fp;
	//fp = fopen("current_parking_list.txt", "at");
	fp = fopen("current_parking_list.txt", "at");
	struct date stdate;
	getdate(&stdate);
	struct time sttime;
	gettime(&sttime);

	gotoxy(0, 0);
	for (int i = 0; i<31; i++) 
	{
		for (int j = 0; j<70; j++) {
			if (i == 3) { printf("                               ��������                               "); j = 70; }
			else if ((i == 5 || i == 11) && (j >= 10 && j <= 60)) { textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); }
			else if ((i == 6 || i == 10) && (j == 10 || j == 60)) { textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); }
			else if (i == 7) {
				textcolor(LIGHTGRAY, BLACK); printf("          "); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" ");
				textcolor(LIGHTGRAY, BLACK);   printf("          ������ȣ : %15s", car_number);
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK); printf("   "); j = 70;
			}
			else if (i == 8) {
				textcolor(LIGHTGRAY, BLACK);  printf("       "); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" ");
				textcolor(LIGHTGRAY, BLACK); printf("         ������ġ :        %d��%c��%c��             ", floor_select, temp[0], temp[1]);
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK); printf("         "); j = 70;
			}
			else if (i == 9) {
				textcolor(LIGHTGRAY, BLACK); printf("          "); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" ");
				textcolor(LIGHTGRAY, BLACK);   printf("         �����ð� :  %4d��%2d��%2d�� %2d��%2d��     ", 2018, 07, 30, 21, 33);
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK); printf("         "); j = 70;
			}
			else { textcolor(LIGHTGRAY, BLACK); printf(" "); }
		}
	}
	fprintf(fp, "%s", car_number);
	fprintf(fp, "%d%c%c", floor_select, temp[0], temp[1]);
	fprintf(fp, "%c", ch);
	fprintf(fp, "%d", stdate.da_year);
	fprintf(fp, "%c", ch);
	fprintf(fp, "%d", stdate.da_mon);
	fprintf(fp, "%c", ch);
	fprintf(fp, "%d", stdate.da_day);
	fprintf(fp, "%c", ch);
	fprintf(fp, "%d", sttime.ti_hour);
	fprintf(fp, "%c", ch);
	fprintf(fp, "%d", sttime.ti_min);
	fprintf(fp, "%c", ch);
	fclose(fp);
	//fprintf(fp,"%d\n%d\n%d\n%d\n%d\n", car_number,floor_select, , , stdate.da_year, stdate.da_mon, stdate.da_day, sttime.ti_hour, sttime.ti_min);

	gotoxy(0, 31);
	printf(" �ƹ�Ű�� ������ �ʱ� �޴��� ���ư��ϴ�. ");
}
int parksure(/*List *lp,Parking * pk,*/int(*park_info)[4][8], int floor_select, char *temp, int * empty) 
{
	CLEAR;
	//   �� �� : 	32      �� �� :    70
	//Parking Temp;
	//strcpy(Temp.car_Num,(������ȣ �迭));
	//Temp.car_position[0] = 48+floor_select; Temp.car_position[1]= temp[0]; Temp.car_position[2] = temp[1]; (������ġ)
	// �ð��� �Է��ؾߵ�

	char ch;
	int kFlag;
	gotoxy(0, 0);
	for (int i = 0; i<31; i++) {
		for (int j = 0; j<70; j++) {
			if (i == 4) { printf("     ������ġ : %d �� %c �� %c ��                                        ", floor_select, temp[0], temp[1]); j = 70; }
			else if (i == 5) { printf("     ������ ���� �Ͻðڽ��ϱ�?(y/n)  :                                  "); j = 70; }
			else { printf(" "); }
		}
	}
	while (1)
	{
		gotoxy(0, 31);
		printf(" # �����޴� : backspace  �ʱ�޴� : ESC");
		gotoxy(39, 5);
		ch = inKey(&kFlag);
		if (kFlag == COMMON_KEY && ch == ESC) { return 0; break; }  /* ESC Ű �Է� �� ���� */
		else if (kFlag == COMMON_KEY && ch == BACKSPACE) { return -1; break; }  /* ESC Ű �Է� �� ���� */
		else if (kFlag == COMMON_KEY && (ch == 'y')) {
			//addFirst(lp, &Temp, sizeof(Parking), carMemcpy);
			park_info[floor_select - 1][(int)temp[0] - 65][(int)temp[1] - 49] = 1;
			--(empty[floor_select - 1]);
			return 1; break;
		}
		else if (kFlag == COMMON_KEY && (ch == 'n')) { return 0; break; }
		else { ; }
	}
}
int parkselect(int(*park_info)[4][8], int floor_select, char *temp) 
{
	CLEAR;
	//   �� �� : 	32      �� �� :    70
	char ch;
	int kFlag;
	gotoxy(0, 0);
	for (int i = 0; i<31; i++) {
		for (int j = 0; j<70; j++) {
			if ((i == 0) || (i == 2) || (i == 27) || (i >= 7 && i <= 10) || (i >= 19 && i <= 22)) {
				textcolor(LIGHTGRAY, BLACK); printf(" ");
			}
			else if (i == 1) { printf("                       <%d�� ���� ���� ���>                           ", floor_select); j = 70; }
			else if ((i == 4) || (i == 6) || (i == 11) || (i == 13) || (i == 16) || (i == 18) || (i == 23) || (i == 25)) {
				textcolor(LIGHTGRAY, BLACK); printf("     ");
				for (int k = 0; k<8; k++) {
					textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
					textcolor(LIGHTGRAY, BLACK); printf("   ");
					textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
				} textcolor(LIGHTGRAY, BLACK); printf("         "); j = 70;
			}
			else if ((i == 3) || (i == 14) || (i == 15) || (i == 16) || (i == 26)) {
				textcolor(LIGHTGRAY, BLACK); printf("     ");
				for (int k = 0; k<8; k++) { textcolor(LIGHTGRAY, LIGHTGRAY); printf("       "); }
				textcolor(LIGHTGRAY, BLACK); printf("         "); j = 70;
			}
			else if ((i == 5) || (i == 12) || (i == 17) || (i == 24)) {
				switch (i) {
				case 5: textcolor(LIGHTGRAY, BLACK); printf("  A  ");
					for (int k = 0; k<8; k++) {
						if (park_info[floor_select - 1][0][k] == 0) {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" %d ", k + 1);
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
						else {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTRED); printf("%d", k + 1); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
					} break;
				case 12:textcolor(LIGHTGRAY, BLACK); printf("  B  ");
					for (int k = 0; k<8; k++) {
						if (park_info[floor_select - 1][1][k] == 0) {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" %d ", k + 1);
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
						else {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTRED); printf("%d", k + 1); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
					} break;
				case 17:textcolor(LIGHTGRAY, BLACK); printf("  C  ");
					for (int k = 0; k<8; k++) {
						if (park_info[floor_select - 1][2][k] == 0) {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" %d ", k + 1);
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
						else {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTRED); printf("%d", k + 1); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
					}break;
				case 24:textcolor(LIGHTGRAY, BLACK); printf("  D  ");
					for (int k = 0; k<8; k++) {
						if (park_info[floor_select - 1][3][k] == 0) {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" %d ", k + 1);
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
						else {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTRED); printf("%d", k + 1); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
					}break;
				} textcolor(LIGHTGRAY, BLACK); printf("         "); j = 70;
			}
			else { textcolor(LIGHTGRAY, BLACK); printf(" "); }
		}
	}
	while (1)
	{
		temp[0] = NULL, temp[1] = NULL;
		gotoxy(0, 30);
		printf(" # ������ ��Ҹ� �Է��ϼ��� : \n # �����޴� : backspace  �ʱ�޴� : ESC");
		gotoxy(30, 30);
		ch = inKey(&kFlag);
		if (kFlag == COMMON_KEY && ch == ESC) { return 0; break; }  /* ESC Ű �Է� �� ���� */
		else if (kFlag == COMMON_KEY && ch == BACKSPACE) { return -1; break; }  /* ESC Ű �Է� �� ���� */
		else if (kFlag == COMMON_KEY && (ch == 'A' || ch == 'B' || ch == 'C' || ch == 'D')) {
			temp[0] = ch; ch = inKey(&kFlag);
			if (kFlag == COMMON_KEY && (ch >= 49 && ch <= 56)) {
				if (park_info[floor_select - 1][(int)temp[0] - 65][(int)ch - 49] != 1) { temp[1] = ch; break; }
				else { ; }
			}
			else { ; }
		}
		else { ; }
	}
}
void parkselect_manager(int(*park_info)[4][8], int floor_select, char *temp)
{
	CLEAR;
	//   �� �� : 	32      �� �� :    70
	char ch;
	int kFlag;
	gotoxy(0, 0);
	for (int i = 0; i<31; i++) {
		for (int j = 0; j<70; j++) {
			if ((i == 0) || (i == 2) || (i == 27) || (i >= 7 && i <= 10) || (i >= 19 && i <= 22)) {
				textcolor(LIGHTGRAY, BLACK); printf(" ");
			}
			else if (i == 1) { printf("                       <%d�� ���� ��Ȳ ���>                           ", floor_select); j = 70; }
			else if ((i == 4) || (i == 6) || (i == 11) || (i == 13) || (i == 16) || (i == 18) || (i == 23) || (i == 25)) {
				textcolor(LIGHTGRAY, BLACK); printf("     ");
				for (int k = 0; k<8; k++) {
					textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
					textcolor(LIGHTGRAY, BLACK); printf("   ");
					textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
				} textcolor(LIGHTGRAY, BLACK); printf("         "); j = 70;
			}
			else if ((i == 3) || (i == 14) || (i == 15) || (i == 16) || (i == 26)) {
				textcolor(LIGHTGRAY, BLACK); printf("     ");
				for (int k = 0; k<8; k++) { textcolor(LIGHTGRAY, LIGHTGRAY); printf("       "); }
				textcolor(LIGHTGRAY, BLACK); printf("         "); j = 70;
			}
			else if ((i == 5) || (i == 12) || (i == 17) || (i == 24)) {
				switch (i) {
				case 5: textcolor(LIGHTGRAY, BLACK); printf("  A  ");
					for (int k = 0; k<8; k++) {
						if (park_info[floor_select - 1][0][k] == 0) {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" %d ", k + 1);
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
						else {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTRED); printf("%d", k + 1); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
					} break;
				case 12:textcolor(LIGHTGRAY, BLACK); printf("  B  ");
					for (int k = 0; k<8; k++) {
						if (park_info[floor_select - 1][1][k] == 0) {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" %d ", k + 1);
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
						else {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTRED); printf("%d", k + 1); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
					} break;
				case 17:textcolor(LIGHTGRAY, BLACK); printf("  C  ");
					for (int k = 0; k<8; k++) {
						if (park_info[floor_select - 1][2][k] == 0) {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" %d ", k + 1);
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
						else {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTRED); printf("%d", k + 1); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
					}break;
				case 24:textcolor(LIGHTGRAY, BLACK); printf("  D  ");
					for (int k = 0; k<8; k++) {
						if (park_info[floor_select - 1][3][k] == 0) {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" %d ", k + 1);
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
						else {
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  "); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTRED); printf("%d", k + 1); textcolor(LIGHTGRAY, BLACK); printf(" ");
							textcolor(LIGHTGRAY, LIGHTGRAY); printf("  ");
						}
					}break;
				} textcolor(LIGHTGRAY, BLACK); printf("         "); j = 70;
			}
			else { textcolor(LIGHTGRAY, BLACK); printf(" "); }
		}
	}
	while (1)
	{
		temp[0] = NULL, temp[1] = NULL;
		gotoxy(0, 30);
		printf(" # �����޴� : ESC");
		ch = inKey(&kFlag);
		if (kFlag == COMMON_KEY && ch == ESC) { break; }  /* ESC Ű �Է� �� ���� */
		else if (kFlag == COMMON_KEY && ch == BACKSPACE) {  break; }  /* ESC Ű �Է� �� ���� */
		else if (kFlag == COMMON_KEY && (ch == 'A' || ch == 'B' || ch == 'C' || ch == 'D')) {
			temp[0] = ch; ch = inKey(&kFlag);
			if (kFlag == COMMON_KEY && (ch >= 49 && ch <= 56)) {
				if (park_info[floor_select - 1][(int)temp[0] - 65][(int)ch - 49] != 1) { temp[1] = ch; break; }
				else { ; }
			}
			else { ; }
		}
		else { ; }
	}
	getch();
}
int floorselect(int *e, int *s) 
{
	CLEAR;
	//   �� �� : 	32      �� �� :    70
	int h[6] = { 2,20,24,42,46,64 }, w[2] = { 5,12 }, floor_select, kFlag;
	char ch;
	gotoxy(0, 0);
	for (int i = 0; i<31; i++) {
		for (int j = 0; j<70; j++) {
			if ((i == w[0] || i == w[1]) && ((j >= h[0] && j <= h[1]) || (j >= h[2] && j <= h[3]) || (j >= h[4] && j <= h[5]))) {
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" ");
			}
			else if (((i>w[0] && i< w[0] + 3) || (i>w[1] - 3 && i< w[1])) && (j == h[0] || j == h[1] || j == h[2] || j == h[3] || j == h[4] || j == h[5])) {
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" ");
			}
			else if (i == w[0] + 3) {
				textcolor(LIGHTGRAY, BLACK); printf("  "); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK);
				printf("       1��       "); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK); printf("   ");
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK);
				printf("       2��       "); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK); printf("   ");
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK);
				printf("       3��       "); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" \n"); j = 70;
			}

			else if (i == w[0] + 4) {
				textcolor(LIGHTGRAY, BLACK); printf("  "); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK);
				printf("    (%2d)/(%2d)    ", e[0], s[0]); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK); printf("   ");
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK);
				printf("    (%2d)/(%2d)    ", e[1], s[1]); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK); printf("   ");
				textcolor(LIGHTGRAY, LIGHTGRAY); printf(" "); textcolor(LIGHTGRAY, BLACK);
				printf("    (%2d)/(%2d)    ", e[2], s[2]); textcolor(LIGHTGRAY, LIGHTGRAY); printf(" \n"); j = 70;
			}

			else { textcolor(LIGHTGRAY, BLACK); printf(" "); }
		}
	}
	while (1)
	{
		gotoxy(0, 30);
		printf(" # ���� �Է��ϼ��� : \n # �����޴� : backspace  �ʱ�޴� : ESC");
		gotoxy(21, 30);
		ch = inKey(&kFlag);
		if (kFlag == COMMON_KEY && ch == ESC) { return 0; break; }  /* ESC Ű �Է� �� ���� */
		else if (kFlag == COMMON_KEY && ch == BACKSPACE) { return -1; break; }  /* ESC Ű �Է� �� ���� */
		else if (kFlag == COMMON_KEY && ch == 49) { return 1; break; }
		else if (kFlag == COMMON_KEY && ch == 50) { return 2; break; }
		else if (kFlag == COMMON_KEY && ch == 51) { return 3; break; }
		else { ; }
	}
}
char inKey(int *keyFlag)
{
	char ascii, scan;
	ascii = getch(); // �Էµ� ������ �ƽ�Ű�ڵ带 �Է¹޾ƿ� 
	if (ascii == -32 || ascii == 0) { // �Էµ� ������ �ƽ�Ű�ڵ尡 -32�̰ų� 0�̸� Ư��Ű�� �ԷµȰ��� 
		scan = getch(); // Ư��Ű�� �ԷµǾ��������� scan code���� �Է¹޾ƿ� 
		*keyFlag = SPECIAL_KEY;
		return (scan);
	}
	else { // �Ϲ�Ű�� �ԷµǾ����� 
		*keyFlag = COMMON_KEY;
		return (ascii);
	}
	// getch()�Լ��� Ư��Ű�� �Է¹����� Ascii, Scan code�� ���α׷� ���� ������, 
	// getch()�Լ��� �Ϲ�Ű�� �Է¹����� �׳� Ascii code�� ���α׷� ���� ������ �˴ϴ�. 
	// �����ϼ���~	
}