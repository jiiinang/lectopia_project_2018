﻿#pragma once
#define COMMON_KEY 1 
#define SPECIAL_KEY 0 
#define BACKSPACE 8
#define ENTER 13 
#define ESC 27 
#define BLACK 0
#define LIGHTGRAY 7
#define LIGHTRED 12


char inKey(int *keyFlag); // Ư�� Ű ����
int floorselect(int *e, int *s);
int parkselect(int(*park_info)[4][8], int floor_select, char *temp);
void parkselect_manager(int(*park_info)[4][8], int floor_select, char *temp);
int parksure(/*List *lp, Parking * pk,*/int(*park_info)[4][8], int floor_select, char *temp, int * empty);
void printinfo(char*car_number,int floor_select, char *temp);