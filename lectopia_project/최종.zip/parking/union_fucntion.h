#define BLACK 0
#define DARKGRAY 8
#define LIGHTBLUE 9
#define LIGHTRED 12
#define LIGHTMAGENTA 13
#define WHITE 15
#define LIGHTGREEN 10
#define LIGHTCYAN 11
#define CLEAR system("cls")
#define ESC 27
#pragma once

extern int sum[3];
extern int empty[3];
extern int park_info[3][4][8];
extern char temp_ary[2];

struct time {
	unsigned int ti_hour;
	unsigned int ti_min;
	unsigned int ti_sec;
};

struct date {
	unsigned int da_year;
	unsigned int da_mon;
	unsigned int da_day;
};

void gotoxy(int x, int y);
void myflush();
void draw_box();
void draw_box2();
void textcolor(int foreground, int background);
void getdate(struct date *p);
void gettime(struct time *p);
void park_info_show(char*);
void park_info_show_manager();
//FILE* fileopen(const char *filename, const char *mode);